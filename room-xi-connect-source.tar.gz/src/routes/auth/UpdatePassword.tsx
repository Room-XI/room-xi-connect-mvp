import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Lock, AlertCircle, CheckCircle, ArrowLeft } from 'lucide-react';
import api from '@/lib/api';
import { useSession } from '@/lib/session';

export default function UpdatePassword() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [validatingToken, setValidatingToken] = useState(!!token);
  const [tokenValid, setTokenValid] = useState<boolean | null>(null);
  const [tokenError, setTokenError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const { user } = useSession();

  useEffect(() => {
    // If token is provided, validate it
    if (token) {
      validateToken();
    } else if (!user) {
      // No token and not authenticated - redirect to login
      navigate('/auth/login');
    }
  }, [token, user, navigate]);

  const validateToken = async () => {
    setValidatingToken(true);
    try {
      const { data, error } = await api.auth.validateResetToken(token!);
      if (error) {
        setTokenError(error);
        setTokenValid(false);
      } else if (data?.valid) {
        setTokenValid(true);
      } else {
        setTokenError(data?.error || 'Invalid token');
        setTokenValid(false);
      }
    } catch (err) {
      setTokenError('Failed to validate reset token');
      setTokenValid(false);
    } finally {
      setValidatingToken(false);
    }
  };

  const validatePassword = (password: string) => {
    if (password.length < 12) {
      return 'Password must be at least 12 characters';
    }
    if (!/[A-Z]/.test(password)) {
      return 'Password must contain at least one uppercase letter';
    }
    if (!/[a-z]/.test(password)) {
      return 'Password must contain at least one lowercase letter';
    }
    if (!/[0-9]/.test(password)) {
      return 'Password must contain at least one number';
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      return 'Password must contain at least one special character';
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!password || !confirmPassword) {
      setError('Please fill in all fields');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    const passwordError = validatePassword(password);
    if (passwordError) {
      setError(passwordError);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Use token-based flow if token is provided, otherwise use authenticated flow
      const { error } = token 
        ? await api.auth.completePasswordReset(token, password)
        : await api.auth.updatePassword(password);

      if (error) {
        setError(error);
        return;
      }

      setSuccess(true);
      
      // Redirect to login after a short delay
      setTimeout(() => {
        navigate('/auth/login');
      }, 3000);
    } catch (error) {
      console.error('Password update error:', error);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Show loading while validating token
  if (validatingToken) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-cream p-6">
        <motion.div
          className="w-full max-w-md text-center space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-20 h-20 mx-auto bg-sage/10 rounded-full flex items-center justify-center">
            <div className="w-8 h-8 border-2 border-deepSage border-t-transparent rounded-full animate-spin" />
          </div>
          <p className="text-textSecondaryLight">Validating your reset link...</p>
        </motion.div>
      </div>
    );
  }

  // Show error if token is invalid
  if (token && tokenValid === false) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-cream p-6">
        <motion.div
          className="w-full max-w-md text-center space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-20 h-20 mx-auto bg-coral/10 rounded-full flex items-center justify-center">
            <AlertCircle className="w-10 h-10 text-coral" />
          </div>
          
          <div className="space-y-3">
            <h1 className="text-2xl font-display font-bold text-deepSage">
              Invalid Reset Link
            </h1>
            <p className="text-textSecondaryLight">
              {tokenError || 'This password reset link is invalid or has expired.'}
            </p>
          </div>

          <div className="cosmic-card p-4 bg-coral/10 border-coral/20">
            <p className="text-sm text-coral">
              Password reset links expire after 24 hours and can only be used once.
            </p>
          </div>

          <div className="space-y-3">
            <Link
              to="/auth/reset"
              className="w-full cosmic-button block text-center"
            >
              Request a New Reset Link
            </Link>
            
            <Link
              to="/auth/login"
              className="inline-flex items-center justify-center space-x-2 text-sm font-medium text-teal hover:text-teal/80 transition-colors w-full"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Sign In</span>
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-cream p-6">
        <motion.div
          className="w-full max-w-md text-center space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-20 h-20 mx-auto bg-teal/10 rounded-full flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-teal" />
          </div>
          
          <div className="space-y-3">
            <h1 className="text-2xl font-display font-bold text-deepSage">
              Password Updated
            </h1>
            <p className="text-textSecondaryLight">
              Your password has been successfully updated. You'll be redirected to the sign in page shortly.
            </p>
          </div>

          <div className="cosmic-card p-4 bg-teal/10 border-teal/20">
            <p className="text-sm text-teal">
              Redirecting in 3 seconds...
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh flex items-center justify-center bg-cream p-6">
      <motion.div
        className="w-full max-w-md space-y-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.div
            className="w-20 h-20 mx-auto bg-cosmic-gradient rounded-full flex items-center justify-center"
            animate={{ 
              rotate: [0, 5, -5, 0],
              scale: [1, 1.05, 1]
            }}
            transition={{ 
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <span className="text-2xl font-display font-bold text-deepSage">
              XI
            </span>
          </motion.div>
          
          <div className="space-y-2">
            <h1 className="text-2xl font-display font-bold text-deepSage">
              Update Password
            </h1>
            <p className="text-textSecondaryLight">
              Enter your new password below
            </p>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <motion.div
            className="cosmic-card p-4 bg-coral/10 border-coral/20 flex items-center space-x-3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <AlertCircle className="w-5 h-5 text-coral flex-shrink-0" />
            <p className="text-sm text-coral">{error}</p>
          </motion.div>
        )}

        {/* Update Form */}
        <motion.form
          onSubmit={handleSubmit}
          className="cosmic-card p-6 space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          {/* Password Field */}
          <div className="space-y-2">
            <label htmlFor="password" className="block text-sm font-medium text-deepSage">
              New Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-textSecondaryLight" />
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter new password"
                className="cosmic-input pl-10 pr-10"
                disabled={loading}
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-textSecondaryLight hover:text-deepSage transition-colors"
                disabled={loading}
              >
                {showPassword ? (
                  <EyeOff className="w-5 h-5" />
                ) : (
                  <Eye className="w-5 h-5" />
                )}
              </button>
            </div>
            
            {/* Password Requirements */}
            {password && (
              <div className="text-xs space-y-1">
                <div className={`flex items-center space-x-2 ${
                  password.length >= 12 ? 'text-teal' : 'text-textSecondaryLight'
                }`}>
                  <div className={`w-1 h-1 rounded-full ${
                    password.length >= 12 ? 'bg-teal' : 'bg-textSecondaryLight'
                  }`} />
                  <span>At least 12 characters</span>
                </div>
                <div className={`flex items-center space-x-2 ${
                  /[A-Z]/.test(password) ? 'text-teal' : 'text-textSecondaryLight'
                }`}>
                  <div className={`w-1 h-1 rounded-full ${
                    /[A-Z]/.test(password) ? 'bg-teal' : 'bg-textSecondaryLight'
                  }`} />
                  <span>At least one uppercase letter</span>
                </div>
                <div className={`flex items-center space-x-2 ${
                  /[a-z]/.test(password) ? 'text-teal' : 'text-textSecondaryLight'
                }`}>
                  <div className={`w-1 h-1 rounded-full ${
                    /[a-z]/.test(password) ? 'bg-teal' : 'bg-textSecondaryLight'
                  }`} />
                  <span>At least one lowercase letter</span>
                </div>
                <div className={`flex items-center space-x-2 ${
                  /[0-9]/.test(password) ? 'text-teal' : 'text-textSecondaryLight'
                }`}>
                  <div className={`w-1 h-1 rounded-full ${
                    /[0-9]/.test(password) ? 'bg-teal' : 'bg-textSecondaryLight'
                  }`} />
                  <span>At least one number</span>
                </div>
                <div className={`flex items-center space-x-2 ${
                  /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password) ? 'text-teal' : 'text-textSecondaryLight'
                }`}>
                  <div className={`w-1 h-1 rounded-full ${
                    /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password) ? 'bg-teal' : 'bg-textSecondaryLight'
                  }`} />
                  <span>At least one special character</span>
                </div>
              </div>
            )}
          </div>

          {/* Confirm Password Field */}
          <div className="space-y-2">
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-deepSage">
              Confirm New Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-textSecondaryLight" />
              <input
                id="confirmPassword"
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm new password"
                className="cosmic-input pl-10 pr-10"
                disabled={loading}
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-textSecondaryLight hover:text-deepSage transition-colors"
                disabled={loading}
              >
                {showConfirmPassword ? (
                  <EyeOff className="w-5 h-5" />
                ) : (
                  <Eye className="w-5 h-5" />
                )}
              </button>
            </div>
            
            {/* Password Match Indicator */}
            {confirmPassword && (
              <div className={`text-xs flex items-center space-x-2 ${
                password === confirmPassword ? 'text-teal' : 'text-coral'
              }`}>
                <div className={`w-1 h-1 rounded-full ${
                  password === confirmPassword ? 'bg-teal' : 'bg-coral'
                }`} />
                <span>
                  {password === confirmPassword ? 'Passwords match' : 'Passwords do not match'}
                </span>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <motion.button
            type="submit"
            disabled={loading || !password || !confirmPassword || password !== confirmPassword}
            className={`w-full cosmic-button ${
              loading || !password || !confirmPassword || password !== confirmPassword 
                ? 'opacity-50 cursor-not-allowed' 
                : ''
            }`}
            whileHover={!loading && password && confirmPassword && password === confirmPassword ? { scale: 1.02 } : {}}
            whileTap={!loading && password && confirmPassword && password === confirmPassword ? { scale: 0.98 } : {}}
          >
            {loading ? (
              <div className="flex items-center justify-center space-x-2">
                <div className="w-4 h-4 border-2 border-deepSage border-t-transparent rounded-full animate-spin" />
                <span>Updating password...</span>
              </div>
            ) : (
              'Update Password'
            )}
          </motion.button>
        </motion.form>

        {/* Security Notice */}
        <motion.div
          className="cosmic-card p-4 bg-sage/10 border-sage/20"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <p className="text-sm text-sage text-center">
            After updating your password, you'll need to sign in again with your new credentials.
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}
