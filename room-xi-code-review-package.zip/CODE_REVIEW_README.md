# Room XI Connect - Code Review Package

## Overview
Room XI Connect is a youth mental health and wellness application (ages 13-25) serving 570+ youth in Edmonton, Alberta. It provides daily mood check-ins, local program discovery, crisis support, and an AI companion (Ximi).

## Tech Stack
- **Frontend:** React 18 + TypeScript + Vite 5 + Tailwind CSS
- **Backend:** Express.js + Node.js
- **Database:** Neon PostgreSQL with Drizzle ORM
- **Mobile:** Capacitor wrapper for iOS/Android
- **Auth:** Session-based with bcrypt, account lockout, email verification

## Package Contents

### `/backend`
- `schema.ts` - Complete Drizzle ORM database schema
- `drizzle/` - Database migrations
- `routes/` - Express API routes (auth, programs, checkins, etc.)
- `middleware/` - Auth, rate limiting, RLS, security, consent enforcement
- `services/` - Business logic (Ximi AI, recommendations, push notifications)
- `schemas/` - Zod validation schemas

### `/frontend`
- `router.tsx` - React Router v6 route configuration
- `vite.config.ts` - Vite build configuration
- `tailwind.config.js` - Tailwind CSS configuration
- `tsconfig.json` - TypeScript configuration

### `/ci-cd-qa`
- `playwright.config.ts` - E2E testing configuration
- `eslint.config.js` - Linting rules
- `tests/` - E2E test suites (guardian consent, offline sync, privacy, etc.)

### `/mobile`
- `capacitor.config.ts` - Capacitor mobile wrapper config
- `android/` - Android Gradle configuration
- `ios/` - iOS project structure

### `/operational`
- `package.json` - Dependencies and scripts
- `SECURITY_ARCHITECTURE.md` - Security implementation details
- `DEPLOYMENT.md` - Deployment procedures
- `BREACH_RUNBOOK.md` - Incident response procedures
- `replit.md` - Project state and architecture notes

### `/compliance`
- `PIA_SUBMISSION.md` - Privacy Impact Assessment
- `XIMI_BIAS_AUDIT.md` - AI bias evaluation
- `YOUTH_COMPREHENSION_STUDY.md` - Youth consent comprehension
- `OFFLINE_TESTING_CHECKLIST.md` - Offline functionality tests

## Key Features
1. **PIPA/PIPEDA Compliance** - Two-tier parental consent, audit logging
2. **Ximi AI Companion** - Crisis detection, trauma-informed responses
3. **Mood Tracking** - 6-level scale with DST-safe streaks
4. **Privacy-Safe Analytics** - K-anonymity, differential privacy (Laplace noise)
5. **Offline Support** - IndexedDB + encrypted sync queue
6. **Push Notifications** - Web Push API with VAPID

## Security Highlights
- Session-based auth with PostgreSQL backing
- Account lockout after 5 failed attempts
- Rate limiting on sensitive endpoints
- End-to-end encryption for sensitive data
- bcrypt with 12 rounds for password hashing

## Note on Secrets
All secrets (.env files, API keys, database credentials) have been excluded from this package. See `DEPLOYMENT.md` for required environment variables.

---
Package generated: $(date -u +"%Y-%m-%d %H:%M UTC")
